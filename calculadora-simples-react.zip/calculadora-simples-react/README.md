# Calculadora Simples em React JS

Projeto desenvolvido como exercício de React JS utilizando Vite.

## Objetivo

Criar uma calculadora simples capaz de realizar as quatro operações matemáticas básicas:

- Adição
- Subtração
- Multiplicação
- Divisão

## Funcionalidades

- Campo para o primeiro número
- Campo para o segundo número
- Seleção da operação matemática com `<select>`
- Botão **Calcular**
- Botão **Limpar**
- Exibição do resultado na tela
- Validação de campos vazios
- Tratamento de divisão por zero
- Layout responsivo

## Conceitos aplicados

### Componentes

A calculadora foi criada em um componente separado chamado `FormCalculadora.jsx`, localizado na pasta `src/components`.

### useState

Foi utilizado o hook `useState` para armazenar e atualizar:

- Primeiro número
- Segundo número
- Operação selecionada
- Resultado
- Mensagens de erro

### Eventos

O projeto utiliza eventos do React, como:

- `onChange` para atualizar os campos
- `onSubmit` para realizar o cálculo
- `onClick` para limpar o formulário

### Renderização condicional

A tela exibe o resultado ou uma mensagem de erro de acordo com a ação realizada pelo usuário.

### CSS

O componente possui um arquivo CSS próprio, `FormCalculadora.css`, responsável pela estilização da calculadora.

## Estrutura do projeto

```text
calculadora-simples-react/
├── src/
│   ├── components/
│   │   ├── FormCalculadora.jsx
│   │   └── FormCalculadora.css
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── index.html
├── package.json
└── README.md
```

## Como executar

Instale as dependências:

```bash
npm install
```

Execute o projeto:

```bash
npm run dev
```

Depois, abra no navegador o endereço exibido no terminal pelo Vite.

## Como criar um projeto semelhante do zero

```bash
npm create vite@latest .
```

Depois selecione:

- React
- JavaScript

Em seguida:

```bash
npm install
npm run dev
```

## Autor

Projeto desenvolvido para prática dos conceitos básicos de React JS.
