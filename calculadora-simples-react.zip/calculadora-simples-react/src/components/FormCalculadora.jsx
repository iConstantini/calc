import { useState } from 'react'
import './FormCalculadora.css'

function FormCalculadora() {
  const [primeiroNumero, setPrimeiroNumero] = useState('')
  const [segundoNumero, setSegundoNumero] = useState('')
  const [operacao, setOperacao] = useState('+')
  const [resultado, setResultado] = useState(null)
  const [erro, setErro] = useState('')

  function calcular(event) {
    event.preventDefault()
    setErro('')

    if (primeiroNumero === '' || segundoNumero === '') {
      setResultado(null)
      setErro('Preencha os dois números.')
      return
    }

    const numero1 = Number(primeiroNumero)
    const numero2 = Number(segundoNumero)

    if (Number.isNaN(numero1) || Number.isNaN(numero2)) {
      setResultado(null)
      setErro('Digite apenas números válidos.')
      return
    }

    let resultadoCalculo

    switch (operacao) {
      case '+':
        resultadoCalculo = numero1 + numero2
        break
      case '-':
        resultadoCalculo = numero1 - numero2
        break
      case '*':
        resultadoCalculo = numero1 * numero2
        break
      case '/':
        if (numero2 === 0) {
          setResultado(null)
          setErro('Não é possível dividir por zero.')
          return
        }
        resultadoCalculo = numero1 / numero2
        break
      default:
        setResultado(null)
        setErro('Operação inválida.')
        return
    }

    setResultado(resultadoCalculo)
  }

  function limpar() {
    setPrimeiroNumero('')
    setSegundoNumero('')
    setOperacao('+')
    setResultado(null)
    setErro('')
  }

  return (
    <section className="calculadora">
      <h1>Calculadora Simples</h1>
      <p className="subtitulo">Digite dois números e escolha uma operação.</p>

      <form onSubmit={calcular}>
        <div className="campo">
          <label htmlFor="primeiroNumero">Primeiro número</label>
          <input
            id="primeiroNumero"
            type="number"
            step="any"
            value={primeiroNumero}
            onChange={(event) => setPrimeiroNumero(event.target.value)}
            placeholder="Ex.: 10"
          />
        </div>

        <div className="campo">
          <label htmlFor="segundoNumero">Segundo número</label>
          <input
            id="segundoNumero"
            type="number"
            step="any"
            value={segundoNumero}
            onChange={(event) => setSegundoNumero(event.target.value)}
            placeholder="Ex.: 5"
          />
        </div>

        <div className="campo">
          <label htmlFor="operacao">Operação</label>
          <select
            id="operacao"
            value={operacao}
            onChange={(event) => setOperacao(event.target.value)}
          >
            <option value="+">Adição (+)</option>
            <option value="-">Subtração (-)</option>
            <option value="*">Multiplicação (*)</option>
            <option value="/">Divisão (/)</option>
          </select>
        </div>

        <div className="botoes">
          <button className="btn-calcular" type="submit">
            Calcular
          </button>

          <button className="btn-limpar" type="button" onClick={limpar}>
            Limpar
          </button>
        </div>
      </form>

      <div className="resultado">
        {erro && <p className="erro">{erro}</p>}

        {!erro && resultado !== null && (
          <>
            <span>Resultado</span>
            <strong>{resultado}</strong>
          </>
        )}

        {!erro && resultado === null && (
          <p className="mensagem-inicial">O resultado aparecerá aqui.</p>
        )}
      </div>
    </section>
  )
}

export default FormCalculadora
