import FormCalculadora from './components/FormCalculadora'

function App() {
  return (
    <main className="app">
      <FormCalculadora />
    </main>
  )
}

export default App
